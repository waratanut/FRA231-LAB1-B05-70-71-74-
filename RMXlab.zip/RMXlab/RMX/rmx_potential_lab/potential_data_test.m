Data_LA = out.simout;
Poten_LA = zeros(1, 11);

for i=1:11
Poten_LA(1,i)=mean(Data_LA(i,1:100));
end
volt_LA =Poten_LA*(3.3/4095);
percent_LA = Poten_LA*(100/4095);
disp(Poten_LA)
disp(volt_LA)
disp(percent_LA)
