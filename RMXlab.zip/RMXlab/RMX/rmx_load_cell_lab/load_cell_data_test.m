Data_load_cell_real_real = out.simout;
load_cell_real_real = zeros(1, 11);

for i=1:11
load_cell_real_real(1,i)=mean(Data_load_cell_real_real(i,1:100));
end
volt_real_real =load_cell_real_real*(3.3/4095);
kilo_real_real=volt_real_real*4;
disp(load_cell_real_real)
disp(volt_real_real)
disp(kilo_real_real)
