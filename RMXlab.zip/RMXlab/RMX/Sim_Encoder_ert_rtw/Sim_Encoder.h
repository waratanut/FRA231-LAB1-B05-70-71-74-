/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: Sim_Encoder.h
 *
 * Code generated for Simulink model 'Sim_Encoder'.
 *
 * Model version                  : 1.6
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Mon Oct 28 21:18:29 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Sim_Encoder_h_
#define Sim_Encoder_h_
#ifndef Sim_Encoder_COMMON_INCLUDES_
#define Sim_Encoder_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "math.h"
#include "main.h"
#endif                                 /* Sim_Encoder_COMMON_INCLUDES_ */

#include "Sim_Encoder_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* Block states (default storage) for system '<Root>/MATLAB Function1' */
typedef struct {
  real_T Pulse;                        /* '<Root>/MATLAB Function1' */
  real_T LastPulse;                    /* '<Root>/MATLAB Function1' */
  int32_T sfEvent;                     /* '<Root>/MATLAB Function1' */
  boolean_T doneDoubleBufferReInit;    /* '<Root>/MATLAB Function1' */
  boolean_T Pulse_not_empty;           /* '<Root>/MATLAB Function1' */
  boolean_T LastPulse_not_empty;       /* '<Root>/MATLAB Function1' */
} DW_MATLABFunction1_Sim_Encode_T;

/* Block signals (default storage) */
typedef struct {
  real_T count;                        /* '<Root>/x3' */
  real_T count_b;                      /* '<Root>/x2' */
  real_T count_f;                      /* '<Root>/x1' */
  real_T pulse;                        /* '<Root>/MATLAB Function3' */
  real_T pulse_a;                      /* '<Root>/MATLAB Function2' */
  real_T pulse_c;                      /* '<Root>/MATLAB Function1' */
  uint32_T encoderx4;                  /* '<Root>/Encoder2' */
  uint32_T encoderx2;                  /* '<Root>/Encoder1' */
  uint32_T encoderx1;                  /* '<Root>/Encoder' */
  boolean_T dir4;                      /* '<Root>/Encoder2' */
  boolean_T dir2;                      /* '<Root>/Encoder1' */
  boolean_T dir1;                      /* '<Root>/Encoder' */
  boolean_T DigitalPortRead;           /* '<S12>/Digital Port Read' */
  boolean_T DigitalPortRead_o;         /* '<S10>/Digital Port Read' */
} B_Sim_Encoder_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  stm32cube_blocks_EncoderBlock_T obj; /* '<Root>/Encoder2' */
  stm32cube_blocks_EncoderBlock_T obj_n;/* '<Root>/Encoder1' */
  stm32cube_blocks_EncoderBlock_T obj_p;/* '<Root>/Encoder' */
  real_T Count;                        /* '<Root>/x3' */
  real_T Abefore;                      /* '<Root>/x3' */
  real_T Bbefore;                      /* '<Root>/x3' */
  real_T Count_d;                      /* '<Root>/x2' */
  real_T Abefore_p;                    /* '<Root>/x2' */
  real_T Count_o;                      /* '<Root>/x1' */
  real_T Abefore_j;                    /* '<Root>/x1' */
  real_T Pulse;                        /* '<Root>/MATLAB Function3' */
  real_T LastPulse;                    /* '<Root>/MATLAB Function3' */
  boolean_T Count_not_empty;           /* '<Root>/x3' */
  boolean_T Count_not_empty_l;         /* '<Root>/x2' */
  boolean_T Count_not_empty_j;         /* '<Root>/x1' */
  boolean_T LastPulse_not_empty;       /* '<Root>/MATLAB Function3' */
  DW_MATLABFunction1_Sim_Encode_T sf_MATLABFunction2;/* '<Root>/MATLAB Function2' */
  DW_MATLABFunction1_Sim_Encode_T sf_MATLABFunction1;/* '<Root>/MATLAB Function1' */
} DW_Sim_Encoder_T;

/* Real-time Model Data Structure */
struct tag_RTM_Sim_Encoder_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block signals (default storage) */
extern B_Sim_Encoder_T Sim_Encoder_B;

/* Block states (default storage) */
extern DW_Sim_Encoder_T Sim_Encoder_DW;

/* Model entry point functions */
extern void Sim_Encoder_initialize(void);
extern void Sim_Encoder_step(void);
extern void Sim_Encoder_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Sim_Encoder_T *const Sim_Encoder_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Sim_Encoder'
 * '<S1>'   : 'Sim_Encoder/Digital Port Read'
 * '<S2>'   : 'Sim_Encoder/Digital Port Read1'
 * '<S3>'   : 'Sim_Encoder/MATLAB Function1'
 * '<S4>'   : 'Sim_Encoder/MATLAB Function2'
 * '<S5>'   : 'Sim_Encoder/MATLAB Function3'
 * '<S6>'   : 'Sim_Encoder/x1'
 * '<S7>'   : 'Sim_Encoder/x2'
 * '<S8>'   : 'Sim_Encoder/x3'
 * '<S9>'   : 'Sim_Encoder/Digital Port Read/ECSoC'
 * '<S10>'  : 'Sim_Encoder/Digital Port Read/ECSoC/ECSimCodegen'
 * '<S11>'  : 'Sim_Encoder/Digital Port Read1/ECSoC'
 * '<S12>'  : 'Sim_Encoder/Digital Port Read1/ECSoC/ECSimCodegen'
 */
#endif                                 /* Sim_Encoder_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
