/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: qei_read_private.h
 *
 * Code generated for Simulink model 'qei_read'.
 *
 * Model version                  : 1.13
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Fri Nov  1 02:57:34 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef qei_read_private_h_
#define qei_read_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "qei_read.h"
#include "qei_read_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmSetTFinal
#define rtmSetTFinal(rtm, val)         ((rtm)->Timing.tFinal = (val))
#endif

extern void qei_read_MATLABFunction1_Init(DW_MATLABFunction1_qei_read_T *localDW);
extern void qei_read_MATLABFunction1(real_T rtu_u, boolean_T rtu_sw, real_T
  *rty_pulse, real_T *rty_Theta, real_T *rty_V, DW_MATLABFunction1_qei_read_T
  *localDW);

#endif                                 /* qei_read_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
