/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: qei_read.c
 *
 * Code generated for Simulink model 'qei_read'.
 *
 * Model version                  : 1.13
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Fri Nov  1 02:57:34 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "qei_read.h"
#include "rtwtypes.h"
#include "qei_read_types.h"
#include "qei_read_private.h"
#include "stm_timer_ll.h"

/* Named constants for MATLAB Function: '<Root>/MATLAB Function1' */
#define qei_read_CALL_EVENT            (-1)

/* Block signals (default storage) */
B_qei_read_T qei_read_B;

/* Block states (default storage) */
DW_qei_read_T qei_read_DW;

/* Real-time model */
static RT_MODEL_qei_read_T qei_read_M_;
RT_MODEL_qei_read_T *const qei_read_M = &qei_read_M_;

/* Forward declaration for local functions */
static void qei_read_SystemCore_setup_i1(stm32cube_blocks_EncoderBlock_T *obj);
static void qei_read_SystemCore_setup_i(stm32cube_blocks_EncoderBlock_T *obj);
static void qei_read_SystemCore_setup(stm32cube_blocks_EncoderBlock_T *obj);

/*
 * System initialize for atomic system:
 *    '<Root>/MATLAB Function1'
 *    '<Root>/MATLAB Function2'
 */
void qei_read_MATLABFunction1_Init(DW_MATLABFunction1_qei_read_T *localDW)
{
  localDW->sfEvent = qei_read_CALL_EVENT;
}

/*
 * Output and update for atomic system:
 *    '<Root>/MATLAB Function1'
 *    '<Root>/MATLAB Function2'
 */
void qei_read_MATLABFunction1(real_T rtu_u, boolean_T rtu_sw, real_T *rty_pulse,
  real_T *rty_Theta, real_T *rty_V, DW_MATLABFunction1_qei_read_T *localDW)
{
  real_T diff;
  localDW->sfEvent = qei_read_CALL_EVENT;
  if (rtu_sw) {
    localDW->Pulse = 0.0;
    localDW->Pulse_not_empty = true;
  }

  if (!localDW->LastPulse_not_empty) {
    localDW->LastPulse = rtu_u;
    localDW->LastPulse_not_empty = true;
    localDW->Pulse = 0.0;
    localDW->Pulse_not_empty = true;
    localDW->res = 0.26179938779914941;
    localDW->res_not_empty = true;
    localDW->theta_not_empty = true;
    localDW->Theta_prev_not_empty = true;
    localDW->v_not_empty = true;
  }

  diff = rtu_u - localDW->LastPulse;
  if (diff == 65520.0) {
    diff = -1.0;
  }

  if (diff == -65520.0) {
    diff = 1.0;
  }

  localDW->Pulse += diff;
  localDW->theta = localDW->res * localDW->Pulse;
  localDW->v = (localDW->theta - localDW->Theta_prev) / 0.01;
  *rty_V = localDW->v;
  localDW->LastPulse = rtu_u;
  *rty_pulse = localDW->Pulse;
  localDW->Theta_prev = localDW->theta;
  *rty_Theta = localDW->theta;
}

static void qei_read_SystemCore_setup_i1(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/Encoder2' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM5;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/Encoder2' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/Encoder2' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/Encoder2' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

static void qei_read_SystemCore_setup_i(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/Encoder1' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM1;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/Encoder1' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/Encoder1' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/Encoder1' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

static void qei_read_SystemCore_setup(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/Encoder' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM3;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/Encoder' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/Encoder' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/Encoder' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

/* Model step function */
void qei_read_step(void)
{
  real_T diff;
  uint32_T pinReadLoc;
  boolean_T rtb_Compare;
  boolean_T rtb_FixPtRelationalOperator;

  /* MATLABSystem: '<Root>/Encoder2' */
  qei_read_B.qei4 = getTimerCounterValueForG4(qei_read_DW.obj.TimerHandle, false,
    NULL);

  /* MATLABSystem: '<Root>/Encoder2' */
  qei_read_B.dir4 = ouputDirectionOfCounter(qei_read_DW.obj.TimerHandle);

  /* MATLABSystem: '<S8>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOB);

  /* RelationalOperator: '<S6>/Compare' incorporates:
   *  Constant: '<S6>/Constant'
   *  MATLABSystem: '<S8>/Digital Port Read'
   * */
  rtb_Compare = ((pinReadLoc & 2U) != 0U);

  /* RelationalOperator: '<S1>/FixPt Relational Operator' incorporates:
   *  UnitDelay: '<S1>/Delay Input1'
   *
   * Block description for '<S1>/Delay Input1':
   *
   *  Store in Global RAM
   */
  rtb_FixPtRelationalOperator = ((int32_T)rtb_Compare > (int32_T)
    qei_read_DW.DelayInput1_DSTATE);

  /* MATLAB Function: '<Root>/MATLAB Function2' incorporates:
   *  DataTypeConversion: '<Root>/Cast To Double2'
   */
  qei_read_MATLABFunction1((real_T)qei_read_B.qei4, rtb_FixPtRelationalOperator,
    &qei_read_B.pulse, &qei_read_B.Theta, &qei_read_B.V,
    &qei_read_DW.sf_MATLABFunction2);

  /* MATLABSystem: '<Root>/Encoder1' */
  qei_read_B.qei1 = getTimerCounterValueForG4(qei_read_DW.obj_h.TimerHandle,
    false, NULL);

  /* MATLABSystem: '<Root>/Encoder1' */
  qei_read_B.dir1 = ouputDirectionOfCounter(qei_read_DW.obj_h.TimerHandle);

  /* MATLAB Function: '<Root>/MATLAB Function' incorporates:
   *  DataTypeConversion: '<Root>/Cast To Double'
   */
  if (rtb_FixPtRelationalOperator) {
    qei_read_DW.Pulse = 0.0;
  }

  if (!qei_read_DW.LastPulse_not_empty) {
    qei_read_DW.LastPulse = qei_read_B.qei1;
    qei_read_DW.LastPulse_not_empty = true;
    qei_read_DW.Pulse = 0.0;
    qei_read_DW.res = 0.26179938779914941;
  }

  diff = (real_T)qei_read_B.qei1 - qei_read_DW.LastPulse;
  if (diff == 65520.0) {
    diff = -1.0;
  }

  if (diff == -65520.0) {
    diff = 1.0;
  }

  qei_read_DW.Pulse += diff;
  qei_read_B.Theta_o = qei_read_DW.res * qei_read_DW.Pulse;
  qei_read_B.V_f = (qei_read_B.Theta_o - qei_read_DW.Theta_prev) / 0.01;
  qei_read_DW.LastPulse = qei_read_B.qei1;
  qei_read_B.pulse_g = qei_read_DW.Pulse;
  qei_read_DW.Theta_prev = qei_read_B.Theta_o;

  /* End of MATLAB Function: '<Root>/MATLAB Function' */
  /* MATLABSystem: '<Root>/Encoder' */
  qei_read_B.qei2 = getTimerCounterValueForG4(qei_read_DW.obj_p.TimerHandle,
    false, NULL);

  /* MATLABSystem: '<Root>/Encoder' */
  qei_read_B.dir2 = ouputDirectionOfCounter(qei_read_DW.obj_p.TimerHandle);

  /* MATLAB Function: '<Root>/MATLAB Function1' incorporates:
   *  DataTypeConversion: '<Root>/Cast To Double1'
   */
  qei_read_MATLABFunction1((real_T)qei_read_B.qei2, rtb_FixPtRelationalOperator,
    &qei_read_B.pulse_b, &qei_read_B.Theta_e, &qei_read_B.V_k,
    &qei_read_DW.sf_MATLABFunction1);

  /* Update for UnitDelay: '<S1>/Delay Input1'
   *
   * Block description for '<S1>/Delay Input1':
   *
   *  Store in Global RAM
   */
  qei_read_DW.DelayInput1_DSTATE = rtb_Compare;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  qei_read_M->Timing.taskTime0 =
    ((time_T)(++qei_read_M->Timing.clockTick0)) * qei_read_M->Timing.stepSize0;
}

/* Model initialize function */
void qei_read_initialize(void)
{
  /* Registration code */
  rtmSetTFinal(qei_read_M, -1);
  qei_read_M->Timing.stepSize0 = 0.01;

  /* External mode info */
  qei_read_M->Sizes.checksums[0] = (465194207U);
  qei_read_M->Sizes.checksums[1] = (2093291210U);
  qei_read_M->Sizes.checksums[2] = (3812063531U);
  qei_read_M->Sizes.checksums[3] = (10022691U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[8];
    qei_read_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(qei_read_M->extModeInfo,
      &qei_read_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(qei_read_M->extModeInfo, qei_read_M->Sizes.checksums);
    rteiSetTPtr(qei_read_M->extModeInfo, rtmGetTPtr(qei_read_M));
  }

  /* SystemInitialize for MATLAB Function: '<Root>/MATLAB Function2' */
  qei_read_MATLABFunction1_Init(&qei_read_DW.sf_MATLABFunction2);

  /* SystemInitialize for MATLAB Function: '<Root>/MATLAB Function1' */
  qei_read_MATLABFunction1_Init(&qei_read_DW.sf_MATLABFunction1);

  /* Start for MATLABSystem: '<Root>/Encoder2' */
  qei_read_DW.obj.isInitialized = 0;
  qei_read_DW.obj.matlabCodegenIsDeleted = false;
  qei_read_SystemCore_setup_i1(&qei_read_DW.obj);

  /* Start for MATLABSystem: '<Root>/Encoder1' */
  qei_read_DW.obj_h.isInitialized = 0;
  qei_read_DW.obj_h.matlabCodegenIsDeleted = false;
  qei_read_SystemCore_setup_i(&qei_read_DW.obj_h);

  /* Start for MATLABSystem: '<Root>/Encoder' */
  qei_read_DW.obj_p.isInitialized = 0;
  qei_read_DW.obj_p.matlabCodegenIsDeleted = false;
  qei_read_SystemCore_setup(&qei_read_DW.obj_p);
}

/* Model terminate function */
void qei_read_terminate(void)
{
  uint8_T ChannelInfo;

  /* Terminate for MATLABSystem: '<Root>/Encoder2' */
  if (!qei_read_DW.obj.matlabCodegenIsDeleted) {
    qei_read_DW.obj.matlabCodegenIsDeleted = true;
    if ((qei_read_DW.obj.isInitialized == 1) && qei_read_DW.obj.isSetupComplete)
    {
      disableCounter(qei_read_DW.obj.TimerHandle);
      disableTimerInterrupts(qei_read_DW.obj.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(qei_read_DW.obj.TimerHandle, ChannelInfo);
      disableTimerChannel2(qei_read_DW.obj.TimerHandle, ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Encoder2' */
  /* Terminate for MATLABSystem: '<Root>/Encoder1' */
  if (!qei_read_DW.obj_h.matlabCodegenIsDeleted) {
    qei_read_DW.obj_h.matlabCodegenIsDeleted = true;
    if ((qei_read_DW.obj_h.isInitialized == 1) &&
        qei_read_DW.obj_h.isSetupComplete) {
      disableCounter(qei_read_DW.obj_h.TimerHandle);
      disableTimerInterrupts(qei_read_DW.obj_h.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(qei_read_DW.obj_h.TimerHandle, ChannelInfo);
      disableTimerChannel2(qei_read_DW.obj_h.TimerHandle, ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Encoder1' */
  /* Terminate for MATLABSystem: '<Root>/Encoder' */
  if (!qei_read_DW.obj_p.matlabCodegenIsDeleted) {
    qei_read_DW.obj_p.matlabCodegenIsDeleted = true;
    if ((qei_read_DW.obj_p.isInitialized == 1) &&
        qei_read_DW.obj_p.isSetupComplete) {
      disableCounter(qei_read_DW.obj_p.TimerHandle);
      disableTimerInterrupts(qei_read_DW.obj_p.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(qei_read_DW.obj_p.TimerHandle, ChannelInfo);
      disableTimerChannel2(qei_read_DW.obj_p.TimerHandle, ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Encoder' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
